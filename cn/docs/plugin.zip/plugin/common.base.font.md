基础插件引用了以下的图标字体<br/>

- Font Awesome 4.5.0

引用基础插件的css样式即可使用这些图标字体，请参考[基础css样式](common.base.css.md)
