联系人插件提供了针对用户设置手机电话和地址等功能。<br/>

### 联系人的数据结构

![联系人的ER图](../img/er_user_contact.jpg)

### 联系人的前台设置

![联系人的前台设置](../img/user_contract.jpg)

### 联系人的后台设置

![联系人的后台设置](../img/user_contract_from_admin.jpg)
