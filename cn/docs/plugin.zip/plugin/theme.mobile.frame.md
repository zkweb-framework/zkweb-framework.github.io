这个插件改进了手机版访问网站前台时的效果

### 效果图

![效果图](../img/mobile_frame_1.jpg)
![效果图](../img/mobile_frame_2.jpg)
![效果图](../img/mobile_frame_3.jpg)

### 覆盖的模板文件

这个插件重载了以下的模板文件

- common.base/header.html
- common.base/footer.html

如果需要替换底部栏中的链接可以重载footer.html
