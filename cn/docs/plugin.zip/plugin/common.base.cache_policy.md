基础插件提供了以下的缓存隔离策略:<br/>
关于缓存隔离请查看[缓存处理](../core/cache/)。<br/>

- `Ident`
	- 按当前登录用户隔离缓存 (Session.ReleatedId)
