这个插件支持在动态表单中使用代码编辑器

### 代码编辑器的属性列表

**CodeEditor: 代码编辑器生成器**

- Name: 字段名称
- Rows: 行数
- Language: 语言, 例如"html, css, javascript"
- Config: 自定义配置, 传给CodeMiror的配置
- Group: 分组
