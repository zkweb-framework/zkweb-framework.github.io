基础插件引用了以下的css样式<br/>

- Bootstrap 3.3.2
- AdminLTE 2.3.0

基础插件的css样式已整合到一个文件，引用时可以使用

``` html
{% include_css_here "/static/common.base.css/components.css" %}
```
