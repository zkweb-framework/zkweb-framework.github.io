这个插件提供了在前后台切换显示语言的下拉菜单，切换结果会保存在cookies中。<br/>

### 切换菜单的样式

![切换菜单的样式](../img/language_switch_menu.jpg)

### 在后台设置中修改可以切换的语言

![语言切换设置](../img/language_switch_settings.jpg)
