这个插件支持在动态表单中使用时间选择器

### 时间选择器的属性列表

**Date: 日期范围选择器生成器**

- Name: 字段名称
- PlaceHolder: 预置文本
- DateFormat: 时间格式, 例如"yyyy/MM/dd"
- Group: 分组

**DateRange: 日期选择器生成器**

- Name: 字段名称
- BeginPlaceHolder: 开始日期的预置文本
- FinishPlaceHolder: 结束日期的预置文本
- DateFormat: 时间格式, 例如"yyyy/MM/dd"
- Group: 分组
